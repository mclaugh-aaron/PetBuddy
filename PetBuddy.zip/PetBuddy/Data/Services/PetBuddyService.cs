using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PetBuddy.Data.Models;
using PetBuddy.Data.Models.Blog;
using PetBuddy.Data.Models.Events;
using PetBuddy.Data.Models.Pet;
using PetBuddy.Data.Models.PetPhotos;
using PetBuddy.Data.Models.Places;
using PetBuddy.Data.Repository;
using Microsoft.EntityFrameworkCore;
using PetBuddy.Data.Models.User;
using PetBuddy.Data.Security;
using PetBuddy.Data.Models.Dogs;
using PetBuddy.Data.Models.HealthChecker;


namespace PetBuddy.Data.Services
{
    public class PetBuddyService : IPetBuddyService
    {
        private readonly PetBuddyDbContext db;

        public PetBuddyService()
        {
            db = new PetBuddyDbContext();
        }

        public void Initialise()
        {
            db.Initialise();
        }

        // ---------------- Blog Management --------------

        public IList<Post> GetAllPosts(string filter)
        {
            switch(filter)
            {
                case "Adoption":
                return db.Posts.Where(v => v.Category == "Adoption").OrderByDescending(p => p.Id).ToList();
   
                case "Breeding":
                return db.Posts.Where(v => v.Category == "Breeding").OrderByDescending(p => p.Id).ToList();
        
                case "Exercise":
                return db.Posts.Where(v => v.Category == "Exercise").OrderByDescending(p => p.Id).ToList();
        
                case "Health&Nutrition":
                return db.Posts.Where(v => v.Category == "Health&Nutrition").OrderByDescending(p => p.Id).ToList();
        
                case "Training":
                return db.Posts.Where(v => v.Category == "Training").OrderByDescending(p => p.Id).ToList();

                case "Other":
                return db.Posts.Where(v => v.Category == "Other").OrderByDescending(p => p.Id).ToList();
         
                default:
                return db.Posts.OrderByDescending(p => p.Id).ToList();
            }
        }

        public Post AddPost(Post p)
        {
            var post = new Post
            {
                Author = p.Author,
                Category = p.Category,
                Content = p.Content,
                Snippet = p.Snippet,
                Title = p.Title
            };
            db.Posts.Add(post);
            db.SaveChanges();

            return post;
        }

        public bool DeletePost(int id)
        {
            var p = GetPostById(id);
            if (p == null)
            {
                return false;
            }
            db.Posts.Remove(p);
            db.SaveChanges();
            return true;
        }

        public Post GetPostById(int id)
        {
            return db.Posts.Include(p => p.Comments).FirstOrDefault(p => p.Id == id);
        }

        public Post EditPost(int id, Post edited)
        {
            var post = GetPostById(id);
            if (post == null)
            {
                return null;
            }

            post.Title = edited.Title;
            post.Snippet = edited.Snippet;
            post.Category = edited.Category;
            post.Content = edited.Content;
            post.Author = edited.Content;

            db.SaveChanges();

            return post;
        }


        public Comment GetCommentById(int id)
        {
            var comment = db.Comments.Include(p => p.Post).FirstOrDefault(c => c.Id == id);

            if (comment == null)
            {
                return null;
            }
            return comment;
        }

        public Comment AddComment(Comment c)
        {
            var comment = new Comment
            {
                PostId = c.PostId,
                Author = c.Author,
                CommentBody = c.CommentBody
                
            };
            db.Comments.Add(comment);
            db.SaveChanges();
            return comment;
        }

        public bool DeleteComment(int id)
        {
            var comment = db.Comments.FirstOrDefault(c => c.Id == id);

            if (comment == null)
            {
                return false;
            }
            db.Comments.Remove(comment);
            db.SaveChanges();
            return true;
        }

        public Comment AddNewComment (int postId, string commentauthor, string commentBody)
        {
            var c = new Comment
            {
                PostId = postId,
                CommentBody = commentBody,
                Author = commentauthor
            };
            db.Comments.Add(c);
            db.SaveChanges();
            return c;
        }


        // ---------------- Event Management --------------

        public IList<Event> GetAllEvents()
        {
            return db.Events.OrderBy(e => e.EventStart ).ToList();
        }

        public Event AddEvent(Event e)
        {
        
            var newEvent = new Event
            {

                EventStart = e.EventStart,
                EventImage = e.EventImage,
                EventSubject = e.EventSubject,
                EventDescription = e.EventDescription,
                EventLocation = e.EventLocation,
                EventUrl = e.EventUrl,
                EventEnd = e.EventEnd
            };
            db.Events.Add(newEvent);
            db.SaveChanges();
            return newEvent;
        }


        public Event GetEventById(int id)
        {
            var e = db.Events.FirstOrDefault(e => e.Id == id);

            if (e == null)
            {
                return null;
            }
            return e;
        }

        public bool DeleteEvent(int id)
        {
            var e = GetEventById(id);

            if (e == null)
            {
                return false;
            }
            db.Events.Remove(e);
            db.SaveChanges();
            return true;
        }

        public Event EditEvent(int id, Event edited)
        {
            var e = GetEventById(id);
            if (e == null)
            {
                return null;
            }
            e.EventDescription = edited.EventDescription;
            e.EventEnd = edited.EventEnd;
            e.EventLocation = edited.EventLocation;
            e.EventImage = edited.EventImage;
            e.EventStart = edited.EventStart;
            e.EventUrl = edited.EventUrl;
            e.EventSubject = edited.EventSubject;

            db.SaveChanges();
            return e;
        }


          // ---------------- Pet Management --------------


        public IList<Pet> GetAllPets()
        {
            return db.Pets.OrderBy(p => p.PetName).ToList();
        }


        public IList<Pet> GetPetsThatMatchBreed(string filter)
        {
            switch (filter)
            {
               case "Shiranian":
                return db.Pets.Where(p => p.BreedName == BreedName.Shiranian).ToList();

                case "Mutt":
                return db.Pets.Where(p => p.BreedName == BreedName.Mutt).ToList();

                case "Labrador":
                return db.Pets.Where(p => p.BreedName == BreedName.Labrador).ToList();

                case "Akita":
                return db.Pets.Where(p => p.BreedName == BreedName.Akita).ToList();

                case "Beagle":
                return db.Pets.Where(p => p.BreedName == BreedName.Beagle).ToList();

                case "BichonFrise":
                return db.Pets.Where(p => p.BreedName == BreedName.BichonFrise).ToList();

                case "Boxer":
                return db.Pets.Where(p => p.BreedName == BreedName.Boxer).ToList();

                case "Bulldog":
                return db.Pets.Where(p => p.BreedName == BreedName.Bulldog).ToList();

                 case "Chihuahua":
                return db.Pets.Where(p => p.BreedName == BreedName.Chihuahua).ToList();

                case "CockerSpaniel":
                return db.Pets.Where(p => p.BreedName == BreedName.CockerSpaniel).ToList();

                case "Dachshund":
                return db.Pets.Where(p => p.BreedName == BreedName.Dachshund).ToList();

                case "Dalmation":
                return db.Pets.Where(p => p.BreedName == BreedName.Dalmation).ToList();

                case "GermanShepherd":
                return db.Pets.Where(p => p.BreedName == BreedName.GermanShepherd).ToList();

                case "GoldenRetriever":
                return db.Pets.Where(p => p.BreedName == BreedName.GoldenRetriever).ToList();

                case "Greyhound":
                return db.Pets.Where(p => p.BreedName == BreedName.Greyhound).ToList();

                case "JackRussell":
                return db.Pets.Where(p => p.BreedName == BreedName.JackRussell).ToList();

                case "LhasaApso":
                return db.Pets.Where(p => p.BreedName == BreedName.LhasaApso).ToList();

                case "Pug":
                return db.Pets.Where(p => p.BreedName == BreedName.Pug).ToList();

                case "Rottweiler":
                return db.Pets.Where(p => p.BreedName == BreedName.Rottweiler).ToList();

                case "Whippet":
                return db.Pets.Where(p => p.BreedName == BreedName.Whippet).ToList();

                case "YorkshireTettier":
                return db.Pets.Where(p => p.BreedName == BreedName.YorkshireTerrier).ToList();

                default:
                return db.Pets.ToList();    
            }
        }



        public Pet AddPet(Pet p)
        {
            var newPet = new Pet
            {
                PetAge = p.PetAge,
                BreedName = p.BreedName,
                PetName = p.PetName,
                PetBio = p.PetBio,
                PetOwnerName = p.PetOwnerName,
                FacebookAccount = p.FacebookAccount,
                InstagramAccount = p.InstagramAccount,
                PetPicUrl = p.PetPicUrl
                
            };

            db.Pets.Add(newPet);
            db.SaveChanges();
            return newPet;
        }

        public Pet GetPetById(int id)
        {
            var p = db.Pets.Include(p=>p.PetPhotos).OrderByDescending(p=> p.Id).Include(p=> p.PetComments).FirstOrDefault(p => p.Id == id);

            if(p == null)
            {
                return null;
            }
            return p;
        }


        public bool DeletePet(int id)
        {
            var p = GetPetById(id);
            if(p == null)
            {
                return false;
            }
            db.Pets.Remove(p);
            db.SaveChanges();
            return true;
        }

        public Pet EditPet(int Id, Pet edited)
        {
            var p = db.Pets.FirstOrDefault(p => p.Id== Id);
            if( p == null)
            {
                return null;
            }
            p.PetAge = edited.PetAge;
            p.PetBio = edited.PetBio;
            p.PetName = edited.PetName;
            p.PetOwnerName = edited.PetOwnerName;
            p.PetPicUrl = edited.PetPicUrl;
            p.FacebookAccount = edited.FacebookAccount;
            p.InstagramAccount = edited.InstagramAccount;

            db.SaveChanges();
            return p;
        }

        public PetComments GetPetCommentById(int id)
        {
            var comment = db.PetComments.Include(p => p.Pet).FirstOrDefault(c => c.Id == id);

            if (comment == null)
            {
                return null;
            }
            return comment;
        }

        public PetComments AddPetComment(PetComments c)
        {
            var comment = new PetComments
            {
                PetId = c.PetId,
                Author = c.Author,
                CommentBody = c.CommentBody
                
            };
            db.PetComments.Add(comment);
            db.SaveChanges();
            return comment; 
        }

        public PetComments AddNewPetComment (int petId, string petCommentauthor, string petCommentBody)
        {
            var c = new PetComments
            {
                PetId = petId,
                CommentBody = petCommentBody,
                Author = petCommentauthor
            };
            db.PetComments.Add(c);
            db.SaveChanges();
            return c;
        }

        public bool DeletePetComment(int id)
        {
            var comment = db.PetComments.FirstOrDefault(c => c.Id == id);

            if (comment == null)
            {
                return false;
            }
            db.PetComments.Remove(comment);
            db.SaveChanges();
            return true;
        }

        public PetPhoto AddPetPhoto (PetPhoto p)
        {
            var photo = new PetPhoto
            {
                PetId = p.PetId,
                PetPhotoUrl = p.PetPhotoUrl
                
            };
            db.PetPhotos.Add(photo);
            db.SaveChanges();
            return photo;
        }

        public PetPhoto AddNewPetPhoto (int petid, string photoUrl)
        {
            var photo = new PetPhoto
            {
                PetId = petid,
                PetPhotoUrl = photoUrl
            };
            db.PetPhotos.Add(photo);
            db.SaveChanges();
            return photo;
        }

        public PetPhoto GetPetPhotoById(int id)
        {
            var photo = db.PetPhotos.Include(p => p.Pet).FirstOrDefault(c => c.Id == id);

            if (photo == null)
            {
                return null;
            }
            return photo;
        }

        public bool DeletePetPhoto(int id)
        {
            var photo = db.PetPhotos.FirstOrDefault(c => c.Id == id);

            if (photo == null)
            {
                return false;
            }
            db.PetPhotos.Remove(photo);
            db.SaveChanges();
            return true;
        }

        // ---------------- Pet Photos Management --------------

        public IList<Photo> GetPhotos()
        {
            return db.Photos.OrderByDescending(p => p.PhotoPostedOnDate).ToList();
        }

        public Photo AddPhoto(Photo p)
        {
            var photo = new Photo
            {
                PetOwner = p.PetOwner,
                PetPhotoUrl = p.PetPhotoUrl,
                PhotoTitle = p.PhotoTitle
            };
            db.Photos.Add(photo);
            db.SaveChanges();
            return photo;
        }

        public Photo GetPhotobyId(int id)
        {
            var photo = db.Photos.FirstOrDefault(p => p.Id == id);

            if(photo == null)
            {
                return null;
            }
            return photo;
        }

        public bool DeletePhoto(int id)
        {
            var p = GetPhotobyId(id);
            if(p == null)
            {
                return false;
            }
            db.Photos.Remove(p);
            db.SaveChanges();
            return true;
        }

        public IList<Photo> GetPhotoByPetName(string petName)
        {
            var photo = db.Photos.Where(p => p.PetName == petName).ToList();

            if(photo == null)
            {
                return null;
            }
            return photo;
        }

        public bool DeletePhotoComment(int id)
        {
            var comment = db.PhotoComments.FirstOrDefault(c => c.Id == id);

            if(comment == null)
            {
                return false;
            }
            db.PhotoComments.Remove(comment);
            db.SaveChanges();
            return true;
        }

        public PhotoComment AddPhotoComment(PhotoComment c)
        {
            var newComment = new PhotoComment
            {
                PhotoCommentAuthor = c.PhotoCommentAuthor,
                PhotoCommentBody = c.PhotoCommentBody,
            };
            db.PhotoComments.Add(newComment);
            db.SaveChanges();
            return newComment;
        }

        public PhotoComment GetPhotoComment(int Id)
        {
            var photoComment = db.PhotoComments.Include(p => p.Photo).FirstOrDefault(p => p.Id == Id);

            if(photoComment == null)
            {
                return null;
            }
            return photoComment;
        }


        // ---------------- Places Management --------------
        public IList<Location> GetLocations(string filter=null)
        {
            switch(filter)
            {
                case "Groomers":
                return db.Locations.Where(v => v.LocationType == "Groomers").ToList();
   
                case "Vets":
                return db.Locations.Where(v => v.LocationType == "Vets").ToList();
        
                case "Exercise":
                return db.Locations.Where(v => v.LocationType == "Exercise").ToList();
        
                case "Training":
                return db.Locations.Where(v => v.LocationType == "Training").ToList();
        
                case "Cafes":
                return db.Locations.Where(v => v.LocationType == "Cafes").ToList();

                case "PetStore":
                return db.Locations.Where(v => v.LocationType == "PetStore").ToList();

                case "Other":
                return db.Locations.Where(v => v.LocationType == "Other").ToList();
         
                default:
                return db.Locations.OrderBy(v => v.LocationName).ToList();
            }
        }

        public IList<Location> GetLocationByType(string locationType)
        {
            var locations = db.Locations.Where(l => l.LocationType == locationType).ToList();

            if(locations == null)
            {
                return null;
            }

            return locations;
        }

        public bool DeleteLocation(int id)
        {
            var location = db.Locations.FirstOrDefault(p => p.Id == id);

            if(location == null)
            {
                return false;
            }
            db.Locations.Remove(location);
            db.SaveChanges();
            return true;
        }

        public Location AddLocation(Location l)
        {

            var newLocation = new Location
            {
                LocationName = l.LocationName,
                LocationAddress1 = l.LocationAddress1,
                LocationAddress2 = l.LocationAddress2,
                LocationEmail = l.LocationEmail,
                LocationEmbedMap = l.LocationEmbedMap,
                LocationPostCode = l.LocationPostCode,
                LocationTel = l.LocationTel,
                LocationType = l.LocationType
            };
            db.Locations.Add(newLocation);
            db.SaveChanges();
            return newLocation;
            }

        public Location GetLocationById(int id) {

            var location = db.Locations.FirstOrDefault(l => l.Id == id);

            if(location == null)
            {
                return null;
            }

            return location;
        }

        public Location EditLocation(int id, Location edited)
        {
            var location = GetLocationById(id);
            if(location == null)
            {
                return null;
            };

            location.LocationAddress1 = edited.LocationAddress1;
            location.LocationAddress2 = edited.LocationAddress2;
            location.LocationEmail = edited.LocationEmail;
            location.LocationEmbedMap = edited.LocationEmbedMap;
            location.LocationName = edited.LocationName;
            location.LocationPostCode = edited.LocationPostCode;
            location.LocationTel = edited.LocationTel;
            location.LocationType = edited.LocationType;

            db.SaveChanges();
            return location;
            }

            public IList<LocationSuggestion> GetLocationSuggestion()
            {
            return db.LocationSuggestions.ToList();
            }

            public bool DeleteLocationSuggestion(int id)
            {
            var locationSuggestion = db.LocationSuggestions.FirstOrDefault(ls => ls.Id == id);
            if( locationSuggestion == null)
            {
                return false;
            }
            db.LocationSuggestions.Remove(locationSuggestion);
            db.SaveChanges();
            return true;
            }

            public LocationSuggestion GetLocationSuggestionById(int id) {

            var suggestion = db.LocationSuggestions.FirstOrDefault(l => l.Id == id);

            if(suggestion == null)
            {
                return null;
            }

            return suggestion;
        }

            public LocationSuggestion AddLocationSuggestion(LocationSuggestion ls)
        {
            var exists = db.Locations.FirstOrDefault(l => l.LocationName == ls.SuggestionName);

            if(exists != null)
            {
                return null;
            }
            var newls = new LocationSuggestion
            {
                SuggestionName = ls.SuggestionName,
                SuggestionAddress1 = ls.SuggestionAddress1,
                SuggestionAddress2 = ls.SuggestionAddress2,
                SuggestionEmail = ls.SuggestionEmail,
                SuggestionPostCode = ls.SuggestionPostCode,
                SuggestionTel = ls.SuggestionTel,
                SuggestionType = ls.SuggestionType
            };
            db.LocationSuggestions.Add(newls);
            db.SaveChanges();
            return newls;
        }


          // ---------------- User Management --------------

        public IList<User> GetAllUsers()
        {
            return db.Users.ToList();
        }

        public User GetUser(int id)
        {
            return db.Users.FirstOrDefault(u => u.Id == id);
        }

        public User RegisterUser(string name, string email, string password, Role role)
        {

            var found = GetUserByEmailAddress(email);

          
            if(found !=null)
            {
                return null;
            }


            var user = new User {
                Name=name, 
                EmailAddress=email, 
                Password=Hasher.CalculateHash(password), 
                Role=role};

            db.Users.Add(user); 
            db.SaveChanges();

            return user;
        }


        public User GetUserByEmailAddress(string email)
        {
            return db.Users.FirstOrDefault(u => u.EmailAddress == email);
        }

        public User Authenticate(string email, string password)
        {
            // retrieve the user based on the EmailAddress (assumes EmailAddress is unique)
            var user = GetUserByEmailAddress(email);

            // Verify the user exists and Hashed User password matches the password provided
            return (user != null && Hasher.ValidateHash(user.Password, password)) ? user : null;
        }


        public bool DeleteUser(int id)
        {
            var u = GetUserById(id);

            if(u == null)
            {
                return false;
            }
            db.Users.Remove(u);
            db.SaveChanges();
            return true;
        }

            public User EditUser(int Id, User user)
        {
            var u = db.Users.FirstOrDefault(p => p.Id== Id);
            if( u == null)
            {
                return null;
            }
            u.EmailAddress = user.EmailAddress;
            u.Name = user.Name;
            u.Role = user.Role;

            db.SaveChanges();
            return u;
        }

            public User GetUserById(int id) {

            var user = db.Users.FirstOrDefault(l => l.Id == id);

            if(user == null)
            {
                return null;
            }

            return user;
        }

        public User EditDetailsByUser(int Id, User user)
        {
            var u = db.Users.FirstOrDefault(p => p.Id== Id);
            if( u == null)
            {
                return null;
            }
            u.EmailAddress = user.EmailAddress;
            u.Name = user.Name;
            u.Password = Hasher.CalculateHash(user.Password);
            u.Role = user.Role;

            db.SaveChanges();
            return u;
        }



             // ---------------- Dog Breed Management --------------

            public Breed AddBreed(Breed p)
            {
                var newBreed = new Breed{
                    ExerciseTime = p.ExerciseTime,
                    BreedType = p.BreedType,
                    LocationOfLiving = p.LocationOfLiving,
                    DogSize = p.DogSize,
                    SizeOfHome = p.SizeOfHome,
                    BreedGroup = p.BreedGroup,
                    BreedLifeExpectancy = p.BreedLifeExpectancy,
                    BreedOrigin = p.BreedOrigin,
                    ShedsHair = p.ShedsHair,
                    SmallChildren = p.SmallChildren,
                    AlreadyHaveADog = p.AlreadyHaveADog,
                    BreedDetails1 = p.BreedDetails1,
                    BreedDetails2 = p.BreedDetails2,
                    HoursAtHome = p.HoursAtHome
                };
            db.Breeds.Add(newBreed);
            db.SaveChanges();
            return newBreed;
            }

            public Breed MatchingBreed (QuizAnswers p)
            {
                var dog = db.Breeds.FirstOrDefault(e => e.ExerciseTime == p.ExerciseTime
                                        && e.HoursAtHome == p.HoursAtHome
                                        && e.LocationOfLiving ==p.LocationOfLiving
                                        && e.ShedsHair == p.ShedsHair
                                        && e.SmallChildren ==p.SmallChildren
                                        && e.AlreadyHaveADog ==p.AlreadyHaveADog
                                        && e.SizeOfHome == p.SizeOfHome);

                return dog;
            }


            // ---------------- HealthChecker Management --------------

            public Illness AddIllness (Illness i)
            {
                var newIllness = new Illness
                {
                    IllnessName = i.IllnessName,
                    IllnessDescription1 = i.IllnessDescription1,
                    IllnessSeriousness = i.IllnessSeriousness,
                    IllnessDescription2 = i.IllnessDescription2,
                    AbdomenPainful = i.AbdomenPainful,
                    AbdomenSwollen = i.AbdomenSwollen,
                    BarkingConstantly = i.BarkingConstantly,
                    BloodInStool = i.BloodInStool,
                    BloodInUrine = i.BloodInUrine,
                    BreathAbnormal = i.BreathAbnormal,
                    Coughing = i.Coughing,
                    Constipated = i.Constipated,
                    CryingConstantly = i.CryingConstantly,
                    DefacationPainful = i.DefacationPainful,
                    Diarrhea = i.Diarrhea,
                    Drooling = i.Drooling,
                    EatingNothing = i.EatingNothing,
                    HairLoss = i.HairLoss,
                    ItchingAndScratching = i.ItchingAndScratching,
                    Limping = i.Limping,
                    Panting = i.Panting,
                    ReverseSneezing = i.ReverseSneezing,
                    UrinationPainful = i.UrinationPainful,
                    WeightGain = i.WeightGain,
                };
                db.Illnesses.Add(newIllness);
                db.SaveChanges();
                return newIllness;
            }

            public Illness MatchingIllness (Symptoms symptoms)
            {
                var illness = db.Illnesses.FirstOrDefault(e => e.AbdomenSwollen == symptoms.AbdomenSwollen
                                                && e.AbdomenSwollen ==symptoms.AbdomenSwollen
                                                && e.BarkingConstantly == symptoms.BarkingConstantly
                                                && e.BloodInStool == symptoms.BloodInStool
                                                && e.BloodInUrine == symptoms.BloodInUrine
                                                && e.Constipated == symptoms.Constipated
                                                && e.Coughing == symptoms.Coughing
                                                && e.CryingConstantly == symptoms.CryingConstantly
                                                && e.DefacationPainful == symptoms.DefacationPainful
                                                && e.Diarrhea == symptoms.Diarrhea
                                                && e.Drooling == symptoms.Drooling
                                                && e.EatingNothing == symptoms.EatingNothing
                                                && e.HairLoss == symptoms.HairLoss
                                                && e.ItchingAndScratching ==symptoms.ItchingAndScratching
                                                && e.Limping == symptoms.Limping
                                                && e.Panting == symptoms.Panting
                                                && e.ReverseSneezing == symptoms.ReverseSneezing
                                                && e.UrinationPainful == symptoms.UrinationPainful
                                                && e.WeightGain == symptoms.WeightGain
                                                );

                return illness;
            }
    

    }
}
