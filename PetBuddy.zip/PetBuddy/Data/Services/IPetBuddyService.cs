using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PetBuddy.Data.Models;
using PetBuddy.Data.Services;
using Microsoft.EntityFrameworkCore;
using PetBuddy.Data.Models.Blog;
using PetBuddy.Data.Models.Events;
using PetBuddy.Data.Models.Pet;
using PetBuddy.Data.Models.PetPhotos;
using PetBuddy.Data.Models.Places;
using PetBuddy.Data.Models.Dogs;
using PetBuddy.Data.Models.User;
using PetBuddy.Data.Models.HealthChecker;

namespace PetBuddy.Data.Services
{
    public interface IPetBuddyService
    {
        // ------------- User Management -------------------
        User Authenticate(string email, string password);
        User RegisterUser(string name, string email, string password, Role role);
        User GetUserByEmailAddress(string email);
        IList<User> GetAllUsers();
        User GetUser(int id);

        bool DeleteUser(int id);

        User EditUser (int id, User user);

        User GetUserById(int id);

        User EditDetailsByUser(int Id, User user);

        void Initialise();

        // ---------------- Blog Management --------------

        IList<Post> GetAllPosts(string filter=null);

        Post AddPost(Post P);

        bool DeletePost(int id);

        Post EditPost(int id, Post edited);

        Post GetPostById(int id);

        Comment GetCommentById(int id);

        Comment AddComment(Comment c);

        Comment AddNewComment (int postId, string commentauthor, string commentBody);

        bool DeleteComment(int id);



        // ---------------- Event Management --------------


        IList<Event> GetAllEvents();
         
        Event AddEvent(Event e);

        bool DeleteEvent(int id);

        Event EditEvent(int id, Event edited);

        Event GetEventById(int id);



        // ---------------- Pet Management --------------


        IList<Pet> GetAllPets();

        IList<Pet> GetPetsThatMatchBreed(string filter);

        Pet AddPet(Pet p);

        bool DeletePet(int id);

        Pet EditPet(int Id, Pet edited);

        Pet GetPetById(int id);

        PetComments GetPetCommentById(int id);

        PetComments AddPetComment(PetComments c);

        PetComments AddNewPetComment (int postId, string commentauthor, string commentBody);

        bool DeletePetComment(int id);

        PetPhoto AddPetPhoto (PetPhoto p);

        PetPhoto AddNewPetPhoto (int petId, string photoUrl);

        PetPhoto GetPetPhotoById(int id);

        bool DeletePetPhoto(int id);


        // ---------------- Pet Photos Management --------------


        IList<Photo> GetPhotos();

        Photo AddPhoto(Photo p);

        bool DeletePhoto(int id);

        Photo GetPhotobyId(int id);

        IList<Photo> GetPhotoByPetName(string petName);

        bool DeletePhotoComment(int id);

        PhotoComment AddPhotoComment(PhotoComment c);

        PhotoComment GetPhotoComment(int Id);


        // ---------------- Places Management --------------


        IList<Location> GetLocations(string filter=null);

        IList<Location> GetLocationByType(string locationType);

        bool DeleteLocation(int id);

        Location AddLocation(Location l);

        Location GetLocationById(int id);
        LocationSuggestion GetLocationSuggestionById(int id);

        Location EditLocation(int id, Location edited);

        IList<LocationSuggestion> GetLocationSuggestion();

        bool DeleteLocationSuggestion(int id);

        LocationSuggestion AddLocationSuggestion(LocationSuggestion ls);


        // ---------------- PetQuiz Management --------------

        Breed AddBreed(Breed p);

        Breed MatchingBreed (QuizAnswers p);

        // ---------------- HealthChecker Management --------------

    
        Illness AddIllness (Illness i);

        Illness MatchingIllness (Symptoms symptoms);







    }
}
