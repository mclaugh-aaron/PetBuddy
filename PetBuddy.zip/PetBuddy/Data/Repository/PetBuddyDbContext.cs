using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using PetBuddy.Data.Models.Blog;
using PetBuddy.Data.Models.Events;
using PetBuddy.Data.Models.PetPhotos;
using PetBuddy.Data.Models.Places;
using PetBuddy.Data.Models.Pet;
using PetBuddy.Data.Models.User;
using PetBuddy.Data.Models.Dogs;
using PetBuddy.Data.Models.HealthChecker;

namespace PetBuddy.Data.Repository
{
    public class PetBuddyDbContext : DbContext
    {
        //Relations created for Database
        public DbSet<Comment> Comments { get; set; }

        public DbSet<Post> Posts { get; set; }

        public DbSet<Pet> Pets { get; set; }

        public DbSet<Event> Events { get; set; }

        public DbSet<Photo> Photos { get; set; }

        public DbSet<PhotoComment> PhotoComments { get; set; }

        public DbSet<Location> Locations { get; set; }

        public DbSet<LocationSuggestion> LocationSuggestions { get; set; }

        public DbSet<Breed> Breeds {get; set;}

        public DbSet<User> Users { get; set; }

        public DbSet<Illness> Illnesses {get; set; }

        public DbSet<PetComments> PetComments { get; set; }

        public DbSet<PetPhoto> PetPhotos { get; set; }

        public void Initialise()
        {
            Database.EnsureDeleted();
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Filename=PetBuddy.db").UseLoggerFactory(new ServiceCollection()
		.AddLogging(builder => builder.AddConsole())
		.BuildServiceProvider()
		.GetService<ILoggerFactory>());

        }

        // Creates a Sql Query console logger that can be added to context for debugging 
        private static ILoggerFactory GetConsoleLoggerFactory()
        {
            IServiceCollection serviceCollection = new ServiceCollection();
            serviceCollection.AddLogging(builder => builder.AddConsole().AddFilter(DbLoggerCategory.Query.Name, LogLevel.Information));
            return serviceCollection.BuildServiceProvider().GetService<ILoggerFactory>();
        }

    }
}