using System;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Pet
{
    public class PetPhoto
    {     
        // PetPhoto class and attributes
        public int Id { get; set; }
        [Required]
        public string PetPhotoUrl { get; set; }
        public int PetId { get; set; }
        public Pet Pet {get; set;}
    }   
}