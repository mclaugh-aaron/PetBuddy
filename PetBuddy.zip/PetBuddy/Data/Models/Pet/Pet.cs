using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Pet
{
    // Pet class and attributes
        public enum BreedName { Akita, Beagle, BichonFrise, Boxer, Bulldog, Chihuahua, CockerSpaniel,
                                 Dalmation, Dachshund, GermanShepherd, GoldenRetriever, Greyhound,
                                 JackRussell, Labrador, LhasaApso, Mutt, Pug, Rottweiler, Shiranian, Whippet,
                                 YorkshireTerrier}
    public class Pet
    {
        public int Id { get; set; }
        [Required]  
        public BreedName BreedName { get; set; }
        [Required]  
        public string PetName { get; set; }
        [Required]  
        public string PetOwnerName { get; set; } 
        public string PetBio { get; set; }
        [Required]  
        public int PetAge { get; set; }
        [Required]  
        [Url] 

        public string PetPicUrl { get; set; }

        public string FacebookAccount { get; set; }

        public string InstagramAccount { get; set; }


        public IList<PetPhoto> PetPhotos {get; set;}

        public IList<PetComments> PetComments {get; set;}

    }
}
