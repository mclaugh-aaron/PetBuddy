using System;
using System.ComponentModel.DataAnnotations;   

namespace PetBuddy.Data.Models.User {
    //user class and attributes

    public enum Role { Admin, Member }

    public class User {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string EmailAddress { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public Role Role { get; set; }
    }
}