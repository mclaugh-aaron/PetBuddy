using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.PetPhotos
{
    public class Photo
    {
        //Photo class and attributes
        public int Id { get; set; }
         [Required]          
         public string PhotoTitle { get; set; }
         [Required] 
         [Url] 
        public string PetPhotoUrl { get; set; }
        [Required]  
        public string PetName { get; set; }
        [Required]  
        public string PetOwner { get; set; }
        public DateTime PhotoPostedOnDate => (DateTime.Now);

        public ICollection<PhotoComment> PhotoComments { get; set; }


    }
}
