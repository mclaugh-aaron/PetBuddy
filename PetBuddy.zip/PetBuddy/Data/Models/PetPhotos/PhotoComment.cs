using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.PetPhotos
{
    // PhotoComment class and attributes
    public class PhotoComment
    {
        public int Id { get; set; }
         [Required]  
        public string PhotoCommentBody { get; set; }
         [Required]  
        public string PhotoCommentAuthor { get; set; }

        public DateTime PhotoCommentDate => (DateTime.Now);

        public int PhotoID { get; set; }

        public Photo Photo { get; set; }
    }
}
