using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Places
{
    //LocationSuggestion class
    public class LocationSuggestion
    {
        public int Id { get; set; }
        [Required] 
        public string SuggestionType { get; set; }
        [Required] 
        public string SuggestionName { get; set; }
        [Required] 
        public string SuggestionAddress1 { get; set; }
        [Required] 
        public string SuggestionAddress2 { get; set; }

        public string SuggestionPostCode { get; set; }
        [EmailAddress]
        public string SuggestionEmail { get; set; }
        
        public string SuggestionTel { get; set; }

        public DateTime SuggestedOnDate => (DateTime.Now);

    }
}