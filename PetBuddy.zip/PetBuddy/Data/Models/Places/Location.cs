using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;    

namespace PetBuddy.Data.Models.Places
{
    // Location class and attributes
    public class Location
    {
        public int Id { get; set; }
        [Required] 
        public string LocationType { get; set; }
        [Required] 
        public string LocationName { get; set; }
        [Required] 
        public string  LocationAddress1 { get; set; }

        public string LocationAddress2 { get; set; }
        [Required] 
        public string LocationPostCode { get; set; }
        [EmailAddress]
        public string LocationEmail { get; set; }

        public string LocationTel { get; set; }
        [Required] 
        public string LocationEmbedMap { get; set; }


    }
}
