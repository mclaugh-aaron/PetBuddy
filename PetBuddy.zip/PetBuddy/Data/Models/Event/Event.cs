using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Events
{
    public class Event
    {
            // Event class and attributes
        public int Id { get; set; }
        [Required]        
        public string EventSubject { get; set; }
        [Required]
        public string EventLocation { get; set; }
        [Required]
        public string EventDescription { get; set; }
        [Required]  
        public DateTime EventStart { get; set; }
        [Required]  
        public DateTime EventEnd { get; set; }

        [Required]  
        [Url]
        public string EventUrl { get; set; }
        [Required]
        public string EventImage { get; set; }

        public int EventDaysUntil => (EventStart - DateTime.Now).Days + 1;


    }
}
