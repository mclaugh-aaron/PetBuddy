using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Blog
{
        // post class and attributes
    public class Post
    {
        public int Id { get; set; }
        [Required]
        public string Author { get; set; }

        public DateTime PostedOnDate => (DateTime.Now);
        [Required]
        public string Title { get; set; }
        [Required]
        public string Snippet { get; set; }
        [Required]
        public string Content { get; set; }
        [Required]
        public string Category { get; set; }

        // navigation property to access service's list (1:N)
        public ICollection<Comment> Comments { get; set; }
    }
}
