using System;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Blog
{
    // comment class and attributes
    public class Comment
    {
        public int Id { get; set; }

        [Required]
        public string Author { get; set; }

        public DateTime CommentDATE => (DateTime.Now);
        [Required]
        public string CommentBody { get; set; }

        public int PostId { get; set; }

        public Post Post { get; set; }
    }
}
