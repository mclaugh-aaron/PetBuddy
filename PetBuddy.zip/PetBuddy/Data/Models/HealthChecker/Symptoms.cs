using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.HealthChecker
{
    // Symptom class and attributes
    public class Symptoms
    {
        public bool AbdomenPainful { get; set; }

        public bool AbdomenSwollen { get; set; }

        public bool BarkingConstantly { get; set; }

        public bool BloodInStool { get; set; }

        public bool BloodInUrine { get; set; }

        public bool BreathAbnormal { get; set; }

        public bool Constipated { get; set; }

        public bool Coughing { get; set; }

        public bool CryingConstantly { get; set; }

        public bool Diarrhea { get; set; }

        public bool DefacationPainful { get; set; }

        public bool Drooling { get; set; }

        public bool EatingNothing { get; set; }

        public bool HairLoss { get; set; }

        public bool ItchingAndScratching { get; set; }

        public bool Limping { get; set; }

        public bool Panting { get; set; }

        public bool ReverseSneezing { get; set; }

        public bool UrinationPainful { get; set; }

        public bool WeightGain { get; set; }

    }
}