using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Dogs
{
        // Breed class and attributes
    public enum BreedType { Akita, Beagle, BichonFrise, Boxer, Bulldog, Chihuahua, CockerSpaniel,
                                 Dalmation, Dachshund, GermanShepherd, GoldenRetriever, Greyhound,
                                 JackRussell, Labrador, LhasaApso, Mutt, Pug, Rottweiler, Shiranian, Whippet,
                                 YorkshireTerrier}
    public class Breed
    {
        public int Id { get; set; }
        public BreedType BreedType { get; set; }
        [Required]
        public string ExerciseTime { get; set; }   
        [Required]      
        public string LocationOfLiving { get; set; }

        public string DogSize { get; set; }
        [Required]
        public string SizeOfHome { get; set; }
        public string BreedOrigin { get; set; }

        public string BreedLifeExpectancy { get; set; }

        public string BreedGroup { get; set; }
        [Required]

        public string SmallChildren { get; set; }
        [Required]

        public string HoursAtHome { get; set; }
        [Required]

        public string ShedsHair { get; set; }
        [Required]

        public string AlreadyHaveADog { get; set; }

        public string BreedDetails1 { get; set; }

        public string BreedDetails2 { get; set; }


    }
}