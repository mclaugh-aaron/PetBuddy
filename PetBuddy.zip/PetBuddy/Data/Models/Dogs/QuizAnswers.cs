using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PetBuddy.Data.Models.Dogs
{
        // QuizAnswers class and attributes
    public class QuizAnswers
    {   
        [Required]
        public string ExerciseTime { get; set; }   
        [Required]      
        public string LocationOfLiving { get; set; }
        [Required]
        public string SizeOfHome { get; set; }
        [Required]
        public string SmallChildren { get; set; }
        [Required]
        public string HoursAtHome { get; set; }
        [Required]
        public string ShedsHair { get; set; }
        [Required]
        public string AlreadyHaveADog { get; set; }

    }
}