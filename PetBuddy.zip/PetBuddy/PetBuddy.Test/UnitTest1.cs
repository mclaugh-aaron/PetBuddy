using System;
using Xunit;
using PetBuddy.Data.Models;
using PetBuddy.Data.Services;
using PetBuddy.Data.Repository;
using PetBuddy.Data.Models.Blog;
using PetBuddy.Data.Models.Dogs;
using PetBuddy.Data.Models.Events;
using PetBuddy.Data.Models.HealthChecker;
using PetBuddy.Data.Models.Pet;
using PetBuddy.Data.Models.Places;
using PetBuddy.Data.Models.User;

namespace PetBuddy.Test
{
    public class PBServiceTest
    {
    private readonly IPetBuddyService svc;

        public PBServiceTest()
        {
            svc = new PetBuddyService();

            svc.Initialise();
        }

        // Blog Units Tests v

        [Fact]
        private void AddNew_Post_ShouldAddAllProperties()
        {
            var p = svc.AddPost(new Post{Author = "Aaron",  
                                        Content = "Post Content",
                                        Title = "Post Title",
                                        Snippet = "Post Snippet",
                                        Category = "Training"});

            var o = svc.GetPostById(p.Id);

            Assert.Equal(p.Title, o.Title);
            Assert.Equal(p.Snippet, o.Snippet);
            Assert.Equal(p.Category, o.Category);
            Assert.Equal(p.Content, o.Content);
        }

        [Fact] 
        private void GetAllPosts_WhenNone_ShouldReturn0()
        {
            
            var posts = svc.GetAllPosts();
            var count = posts.Count;

            Assert.Equal(0, count);
        }

        [Fact]
        private void GetPosts_With2Added_ShouldReturn2()
        {
            // arrange
            var v1 = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});
            var v2 = svc.AddPost(new Post{Author="yyy", Title="yyy", Snippet="yyy", Content="xxx", Category="xxx"});

            // act
            var posts = svc.GetAllPosts();
            var count = posts.Count;

            // assert
            Assert.Equal(2, count);
        }

        [Fact] 
        public void GetPost_WhenNone_ShouldReturnNull()
        {
            // act 
            var post = svc.GetPostById(1); // non existent post

            // assert
            Assert.Null(post);
        }

        [Fact] 
        public void GetPost_WhenAdded_ShouldReturnPost()
        {
            //arrange
            var v = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});
            //act
            var nv = svc.GetPostById(v.Id);

            // assert
            Assert.NotNull(nv);
            Assert.Equal(v.Id, nv.Id);
        }

        [Fact]
        public void DeletePost_ThatExists_ShouldReturnTrue()
        {
            // act 
           var v = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});

            var deleted = svc.DeletePost(v.Id);

            // assert
            Assert.True(deleted);
        }

        [Fact]
        public void DeletePost_ThatDoesntExist_ShouldReturnFalse()
        {
            // act 	
            var deleted = svc.DeletePost(8);

            // assert
            Assert.False(deleted);
        }


        [Fact]
        public void Update_ExistingPost_ShouldChangeDetails()
        {
             // act 
            var v = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});

        
            //act
            v.Title="Treats";
            svc.EditPost(v.Id, v);
            var vu = svc.GetPostById(v.Id);

            //Assert
            Assert.Equal(v.Title, vu.Title);
        }

                [Fact]
        public void GetCommentByID_ShouldReturnComment()
        {
           var v = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});
           var c = svc.AddComment(new Comment{PostId=v.Id,CommentBody="yyyyyy", Author="yyy"});

            var ns = svc.GetCommentById(c.Id);

            Assert.NotNull(ns);
            Assert.Equal(c.Id, ns.Id);
        }

                [Fact]
        public void AddNewComment_ShouldAdd()
        {
        var v = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});
        var c = svc.AddComment(new Comment{PostId=v.Id,CommentBody="yyyyyy", Author="yyy"});


        var c2 = svc.GetCommentById(c.Id);

        Assert.NotNull(c2);
        }

        [Fact]
        public void DeleteComment_ShouldDReturnFalse()
        {
        var v = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});
        var c = svc.AddComment(new Comment{PostId=v.Id ,CommentBody="yyyyyy", Author="yyy"});

        var deleted = svc.DeleteComment(c.Id);

        Assert.True(deleted);
        }

        [Fact]
        public void DeleteComment_ThatDoesntExist_ShouldReturnFalse()
        {
        // act 	
        var deleted = svc.DeleteComment(8);

        // assert
        Assert.False(deleted);
        }

        [Fact]
        public void GetAllPosts_ReturnsVehicles()
        {
         var posts = svc.GetAllPosts();
        
        Assert.NotNull(posts);
        }

        [Fact]
        public void GetAllVehicles_ReturnsInOrderOfID()
        {
            var v1 = svc.AddPost(new Post{Author="xxx", Title="xxx", Snippet="xxx", Content="xxx", Category="xxx"});
            var v2 = svc.AddPost(new Post{Author="yyy", Title="yyy", Snippet="yyy", Content="yyy", Category="yyy"});
            
            var s3 = svc.GetAllPosts();

            Assert.Equal(s3[1].Id,v1.Id);
        }

        // Blog Units Tests ^


         // Dog/Breed Units Tests v
        [Fact]
        public void AddBreed_WhenNone_ShouldSetAllProperties()
        {
            //arrange
            var v = new Breed{BreedType=BreedType.Akita, ExerciseTime="2", LocationOfLiving="Cityside", DogSize = "Small", 
                                SizeOfHome="Small", BreedOrigin="Ireland", BreedLifeExpectancy="15", BreedGroup="xxxx",
                                SmallChildren="Yes", HoursAtHome="5", ShedsHair="Yes", AlreadyHaveADog="Yes", BreedDetails1="xxxxxx",
                                BreedDetails2="yyyyyyyy"};

            //act
            Assert.NotNull(v);
            //Assert properties are set
            Assert.Equal("Akita", BreedType.Akita.ToString());
            Assert.Equal("2", v.ExerciseTime);
            Assert.Equal("Cityside", v.LocationOfLiving);
            Assert.Equal("Small", v.DogSize);
            Assert.Equal("Ireland", v.BreedOrigin);
            Assert.Equal("15", v.BreedLifeExpectancy);
            Assert.Equal("xxxx", v.BreedGroup);
            Assert.Equal("Yes", v.SmallChildren);
            Assert.Equal("5", v.HoursAtHome);
            Assert.Equal("Yes", v.ShedsHair);
            Assert.Equal("Yes", v.AlreadyHaveADog);
            Assert.Equal("xxxxxx", v.BreedDetails1);
            Assert.Equal("yyyyyyyy", v.BreedDetails2);

        }

        [Fact]
        public void MatchingBreed_ShouldReturnCorrectBreed()
        {
            //arrange
            var v = new Breed{BreedType=BreedType.Akita, ExerciseTime="2", LocationOfLiving="Cityside", DogSize = "Small", 
                                SizeOfHome="Small", BreedOrigin="Ireland", BreedLifeExpectancy="15", BreedGroup="xxxx",
                                SmallChildren="Yes", HoursAtHome="5", ShedsHair="Yes", AlreadyHaveADog="Yes", BreedDetails1="xxxxxx",
                                BreedDetails2="yyyyyyyy"};

                                svc.AddBreed(v);

            
            var q = new QuizAnswers {ExerciseTime = "2", LocationOfLiving="Cityside", SizeOfHome="Small", SmallChildren="Yes", HoursAtHome="5",
                                    ShedsHair ="Yes", AlreadyHaveADog="Yes"};

            var mb = svc.MatchingBreed(q);

            Assert.Equal(v.BreedType, mb.BreedType);
        }
        // Dog/Breed Units Tests ^

        // Event Units Tests v
        [Fact]
        public void AddEvent_WhenNone_ShouldSetAllProperties()
        {

            var e = new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,10,10), EventEnd = new DateTime(2020,10,10),
                                EventUrl="www.google.com", EventImage="iiiii"};

            svc.AddEvent(e);

            Assert.Equal(e.EventSubject, "xxxx");
            Assert.Equal(e.EventLocation, "yyyyyy");
            Assert.Equal(e.EventDescription, "oooooo");
            Assert.Equal(e.EventStart, new DateTime(2020,10,10));
            Assert.Equal(e.EventEnd, new DateTime(2020,10,10));
            Assert.Equal(e.EventImage, "iiiii");
            Assert.Equal(e.EventUrl, "www.google.com");

        }

        [Fact] 
        public void GetAllEvents_WhenNone_ShouldReturn0()
        {
            
            var events = svc.GetAllEvents();
            var count = events.Count;

            Assert.Equal(0, count);
        }


        [Fact]
        public void GetEvents_With2Added_ShouldReturn2()
        {
            // arrange
            var e1 = new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,10,10), EventEnd = new DateTime(2020,11,11),
                                EventUrl="www.google.com", EventImage="iiiii"};

            var e2 = new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,11,11), EventEnd = new DateTime(2020,11,11),
                                EventUrl="www.google.com", EventImage="iiiii"};
            // act
            svc.AddEvent(e1);
            svc.AddEvent(e2);
            var events = svc.GetAllEvents();
            var count = events.Count;

            // assert
            Assert.Equal(2, count);
        }


        [Fact] 
        private void GetEvent_WhenNone_ShouldReturnNull()
        {
            // act 
            var e = svc.GetEventById(1); // non existent event

            // assert
            Assert.Null(e);
        }

        
        [Fact] 
        private void GetEvent_WhenAdded_ShouldReturnEvent()
        {
            var e = svc.AddEvent(new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,10,10), EventEnd = new DateTime(2020,11,11),
                                EventUrl="www.google.com", EventImage="iiiii"});

            
            //act
            var nv = svc.GetEventById(e.Id);
           
            // assert
            Assert.NotNull(nv);
            Assert.Equal(e.Id,nv.Id);
        }

        [Fact]
        private void DeleteEvent_ThatExists_ShouldReturnTrue()
        {
            // act 
            var e = svc.AddEvent(new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,10,10), EventEnd = new DateTime(2020,11,11),
                                EventUrl="www.google.com", EventImage="iiiii"});
           
            var deleted = svc.DeleteEvent(e.Id);

            // assert
            Assert.True(deleted);
        }

        [Fact]
        private void DeleteEvent_ThatDoesntExist_ShouldReturnFalse()
        {
            // act 	
            var deleted = svc.DeleteEvent(8);

            // assert
            Assert.False(deleted);
        }

        [Fact]
        private void Update_ExistingEvent_ShouldChangeDetails()
        {
             // act 
            var e = svc.AddEvent(new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,10,10), EventEnd = new DateTime(2020,11,11),
                                EventUrl="www.google.com", EventImage="iiiii"});
            //act
            e.EventSubject="TEST";
            svc.EditEvent(e.Id, e);
            var vu = svc.GetEventById(e.Id);

            //Assert
            Assert.Equal(e.EventSubject, vu.EventSubject);
        }

        [Fact]
        public void GetAllEvents_ReturnsVehicles()
        {
            var e = svc.AddEvent(new Event{EventSubject = "xxxx", EventLocation="yyyyyy", EventDescription="oooooo",
                                EventStart = new DateTime(2020,10,10), EventEnd = new DateTime(2020,11,11),
                                EventUrl="www.google.com", EventImage="iiiii"});
         var ev = svc.GetAllEvents();
        
        Assert.NotNull(ev);
        }

        // Event Units Tests ^


         // Dog/Breed Units Tests v
        [Fact]
        public void AddIllness_WhenNone_ShouldSetAllProperties()
        {
            //arrange
            var v = new Illness{IllnessName="Distember", IllnessDescription1="xxx", IllnessDescription2="yyy",IllnessSeriousness="sss",
                                AbdomenPainful=true, AbdomenSwollen=true, BarkingConstantly=true, BloodInStool=true, BloodInUrine=true,
                                BreathAbnormal=true, Constipated=true, Coughing=true, CryingConstantly=true, DefacationPainful=true,
                                Diarrhea=true, Drooling=true, EatingNothing=true, HairLoss=false, ItchingAndScratching=false,
                                Limping=false, Panting=false, ReverseSneezing=false, UrinationPainful=false, WeightGain=false
                                };
            svc.AddIllness(v);

            //act
            Assert.NotNull(v);
            //Assert properties are set
            Assert.Equal("Akita", BreedType.Akita.ToString());
            Assert.Equal(v.IllnessName, "Distember");
            Assert.Equal(v.IllnessDescription1, "xxx");
            Assert.Equal(v.IllnessDescription2, "yyy");
            Assert.Equal(v.IllnessSeriousness, "sss");
            Assert.Equal(v.AbdomenSwollen, true);
            Assert.Equal(v.AbdomenPainful, true);
            Assert.Equal(v.BarkingConstantly, true);
            Assert.Equal(v.BloodInStool, true);
            Assert.Equal(v.BloodInUrine, true);
            Assert.Equal(v.BreathAbnormal, true);
            Assert.Equal(v.Constipated, true);
            Assert.Equal(v.Coughing, true);
            Assert.Equal(v.CryingConstantly, true);
            Assert.Equal(v.DefacationPainful, true);
            Assert.Equal(v.Diarrhea, true);
            Assert.Equal(v.Drooling, true);
            Assert.Equal(v.EatingNothing, true);
            Assert.Equal(v.HairLoss, false);
            Assert.Equal(v.ItchingAndScratching, false);
            Assert.Equal(v.Limping, false);
            Assert.Equal(v.Panting, false);
            Assert.Equal(v.ReverseSneezing, false);
            Assert.Equal(v.UrinationPainful, false);
            Assert.Equal(v.WeightGain, false);
            


        }

        [Fact]
        public void MatchingIllness_ShouldReturnCorrectIllness()
        {
            //arrange
            var v = new Illness{IllnessName="Distember", IllnessDescription1="xxx", IllnessDescription2="yyy",IllnessSeriousness="sss",
                                AbdomenPainful=true, AbdomenSwollen=true, BarkingConstantly=true, BloodInStool=true, BloodInUrine=true,
                                BreathAbnormal=true, Constipated=true, Coughing=true, CryingConstantly=true, DefacationPainful=true,
                                Diarrhea=true, Drooling=true, EatingNothing=true, HairLoss=false, ItchingAndScratching=false,
                                Limping=false, Panting=false, ReverseSneezing=false, UrinationPainful=false, WeightGain=false
                                };
            svc.AddIllness(v);

            
            var s = new Symptoms {AbdomenPainful=true, AbdomenSwollen=true, BarkingConstantly=true, BloodInStool=true, BloodInUrine=true,
                                BreathAbnormal=true, Constipated=true, Coughing=true, CryingConstantly=true, DefacationPainful=true,
                                Diarrhea=true, Drooling=true, EatingNothing=true, HairLoss=false, ItchingAndScratching=false,
                                Limping=false, Panting=false, ReverseSneezing=false, UrinationPainful=false, WeightGain=false};

            var mb = svc.MatchingIllness(s);

            Assert.Equal(v.IllnessName, mb.IllnessName);
        }
        // Dog/Breed Units Tests ^

        
        // Pet Units Tests v
        [Fact]
        public void AddPet_WhenNone_ShouldSetAllProperties()
        {
            //arrange
            var p = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });

            Assert.NotNull(p);
            //Assert properties are set
            Assert.Equal(p.BreedName, BreedName.Akita);
            Assert.Equal(p.PetName, "Lola");
            Assert.Equal(p.PetOwnerName, "Aaron");
            Assert.Equal(p.PetBio, "xxxx");
            Assert.Equal(p.PetAge, 2);
            Assert.Equal(p.PetPicUrl, "www.google.com");
            Assert.Equal(p.FacebookAccount , "www.google.com");
            Assert.Equal(p.InstagramAccount, "www.google.com");
        }

        [Fact] 
        public void GetAllPets_WhenNone_ShouldReturn0()
        {
            
            var pets = svc.GetAllPets();
            var count = pets.Count;

            Assert.Equal(0, count);
        }

        [Fact]
        public void GetPets_With2Added_ShouldReturn2()
        {
            // arrange
            var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });

            var p2 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
            // act
            var vehicles = svc.GetAllPets();
            var count = vehicles.Count;

            // assert
            Assert.Equal(2, count);
        }


        [Fact] 
        public void GetPet_WhenNone_ShouldReturnNull()
        {
            // act 
            var pet = svc.GetPetById(1); // non existent vehicle

            // assert
            Assert.Null(pet);
        }

        [Fact] 
        public void GetPet_WhenAdded_ShouldReturnPet()
        {
            //arrange
            var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });//act
            var nv = svc.GetPetById(p1.Id);

            // assert
            Assert.NotNull(nv);
            Assert.Equal(p1.Id, nv.Id);
        }

        [Fact]
        public void DeletePet_ThatExists_ShouldReturnTrue()
        {
            // act 
           var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });//act

            var deleted = svc.DeletePet(p1.Id);

            // assert
            Assert.True(deleted);
        }

        [Fact]
        public void DeletePet_ThatDoesntExist_ShouldReturnFalse()
        {
            // act 	
            var deleted = svc.DeletePet(8);

            // assert
            Assert.False(deleted);
        }


        [Fact]
        private void Update_ExistingPet_ShouldChangeDetails()
        {
                // act 
            var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
                //act
            p1.PetName="Kelpy";
            svc.EditPet(p1.Id, p1);
            var vu = svc.GetPetById(p1.Id);

                //Assert
            Assert.Equal(p1.PetName, vu.PetName);
        }

        [Fact]
        public void GetPetCommentByID_ShouldReturnService()
        {
            var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
            var c1 = svc.AddPetComment(new PetComments{PetId=p1.Id,Author="Aaron", CommentBody="Test Comment"});

            var ns = svc.GetPetCommentById(p1.Id);

            Assert.NotNull(ns);
            Assert.Equal(c1.Id, ns.Id);
        }

        [Fact]
        public void AddNewPetComment_ShouldAdd()
        {
            var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
            var c1 = svc.AddPetComment(new PetComments{PetId=p1.Id,Author="Aaron", CommentBody="Test Comment"});
        
        var s2 = svc.GetPetCommentById(c1.Id);

        Assert.NotNull(s2);
        }

        [Fact]
        public void DeletePetComment_ShouldDReturnFalse()
        {
        var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
        var c1 = svc.AddPetComment(new PetComments{PetId=p1.Id,Author="Aaron", CommentBody="Test Comment"});

        var deleted = svc.DeletePetComment(c1.Id);

        Assert.True(deleted);
        }

        [Fact]
        public void DeletePetComment_ThatDoesntExist_ShouldReturnFalse()
        {
        // act 	
        var deleted = svc.DeletePetComment(8);

        // assert
        Assert.False(deleted);
        }

        [Fact]
        public void GetAllPets_ReturnsAllPets()
        {
        var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
         var pets = svc.GetAllPets();
        
        Assert.NotNull(pets);
        }

        [Fact]
        public void GetPetPhotoByID_ShouldReturnPhoto()
        {
           var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
            var c1 = svc.AddPetPhoto(new PetPhoto{PetId=p1.Id, PetPhotoUrl="www.google.com",});

            var ns = svc.GetPetPhotoById(c1.Id);

            Assert.NotNull(ns);
           
        }

        [Fact]
        public void AddNewPetPhoto_ShouldAdd()
        {
        var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
            var c1 = svc.AddPetPhoto(new PetPhoto{PetId=p1.Id, PetPhotoUrl="www.google.com"});

        var s2 = svc.GetPetPhotoById(c1.Id);

        Assert.NotNull(s2);
        }

        [Fact]
        public void DeletePetPhoto_ShouldDReturnFalse()
            {
            var p1 = svc.AddPet(new Pet{BreedName=BreedName.Akita, PetName="Lola", PetOwnerName="Aaron", PetBio="xxxx", PetAge=2, PetPicUrl="www.google.com",
                                        FacebookAccount="www.google.com", InstagramAccount="www.google.com", });
            var c1 = svc.AddPetPhoto(new PetPhoto{PetId=p1.Id, PetPhotoUrl="www.google.com"});

            var deleted = svc.DeletePetPhoto(c1.Id);

            Assert.True(deleted);
        }

        [Fact]
        public void DeletePetPhoto_ThatDoesntExist_ShouldReturnFalse()
        {
        // act 	
        var deleted = svc.DeletePetPhoto(8);

        // assert
        Assert.False(deleted);
        }
        // Pet Units Tests ^

        // Location Units Tests v
       [Fact]
        public void AddLocation_WhenNone_ShouldSetAllProperties()
        {
            //arrange
            var l = svc.AddLocation(new Location{LocationName="Test", LocationAddress1="xxxxx", LocationAddress2="yyyyy",
                                                LocationEmail="test@mail.com", LocationEmbedMap="www.google.com",
                                                LocationPostCode="zzzz", LocationTel="028000000", LocationType="Test"});
             //act
            Assert.NotNull(l);
            //Assert properties are set
            Assert.Equal(l.LocationType, "Test");
            Assert.Equal(l.LocationName, "Test");
            Assert.Equal(l.LocationAddress1, "xxxxx");
            Assert.Equal(l.LocationAddress2,"yyyyy");
            Assert.Equal(l.LocationEmail, "test@mail.com");
            Assert.Equal(l.LocationEmbedMap, "www.google.com");
            Assert.Equal(l.LocationTel,"028000000");
            Assert.Equal(l.LocationType, "Test");
        }

        [Fact] 
        public void GetAllLocations_WhenNone_ShouldReturn0()
        {
            
            var locations = svc.GetLocations();
            var count = locations.Count;

            Assert.Equal(0, count);
        }

        
        [Fact]
        public void GetLocations_With2Added_ShouldReturn2()
        {
            // arrange
            var l1 = svc.AddLocation(new Location{LocationName="Test", LocationAddress1="xxxxx", LocationAddress2="yyyyy",
                                                LocationEmail="test@mail.com", LocationEmbedMap="www.google.com",
                                                LocationPostCode="zzzz", LocationTel="028000000", LocationType="Test"});

            var l2 = svc.AddLocation(new Location{LocationName="Test", LocationAddress1="xxxxx", LocationAddress2="yyyyy",
                                                LocationEmail="test@mail.com", LocationEmbedMap="www.google.com",
                                                LocationPostCode="zzzz", LocationTel="028000000", LocationType="Test"});
            
            // act
            var locations = svc.GetLocations();
            var count = locations.Count;

            // assert
            Assert.Equal(2, count);
        }

        [Fact] 
        public void GetLocation_WhenNone_ShouldReturnNull()
        {
            // act 
            var location = svc.GetLocationById(1); // non existent vehicle

            // assert
            Assert.Null(location);
        }


        [Fact] 
        public void GetLocation_WhenAdded_ShouldReturnVehicle()
        {
            //arrange
            var l = svc.AddLocation(new Location{LocationName="Test", LocationAddress1="xxxxx", LocationAddress2="yyyyy",
                                                LocationEmail="test@mail.com", LocationEmbedMap="www.google.com",
                                                LocationPostCode="zzzz", LocationTel="028000000", LocationType="Test"});//act
            var nv = svc.GetLocationById(l.Id);

            // assert
            Assert.NotNull(nv);
            Assert.Equal(l.Id, nv.Id);
        }

        [Fact]
        public void DeleteLocation_ThatExists_ShouldReturnTrue()
        {
            // act 
            var l = svc.AddLocation(new Location{LocationName="Test", LocationAddress1="xxxxx", LocationAddress2="yyyyy",
                                                LocationEmail="test@mail.com", LocationEmbedMap="www.google.com",
                                                LocationPostCode="zzzz", LocationTel="028000000", LocationType="Test"});//act
            var deleted = svc.DeleteLocation(l.Id);

            // assert
            Assert.True(deleted);
        }

        [Fact]
        public void DeleteLocation_ThatDoesntExist_ShouldReturnFalse()
        {
            // act 	
            var deleted = svc.DeleteLocation(8);

            // assert
            Assert.False(deleted);
        }

        [Fact]
        public void Update_ExistingLocation_ShouldChangeDetails()
        {
                   var l = svc.AddLocation(new Location{LocationName="Test", LocationAddress1="xxxxx", LocationAddress2="yyyyy",
                                                LocationEmail="test@mail.com", LocationEmbedMap="www.google.com",
                                                LocationPostCode="zzzz", LocationTel="028000000", LocationType="Test"});//act
                        //act
                        l.LocationName="NewPlace";
                        svc.EditLocation(l.Id, l);
                        var vu = svc.GetLocationById(l.Id);

                        //Assert
                        Assert.Equal(l.LocationName, vu.LocationName);
        }

        [Fact]
        public void GetAllLocations_ReturnsVehicles()
        {
         var locations = svc.GetLocations();
        
        Assert.NotNull(locations);
        }

        // Location Units Tests ^

        // LocationSuggestion Units Tests v
        [Fact]
        public void AddSuggestion_WhenNone_ShouldSetAllProperties()
        {
            //arrange
            var ls = svc.AddLocationSuggestion(new LocationSuggestion{SuggestionType="Test", SuggestionAddress1="xxxx", SuggestionAddress2="yyyy",
                                                    SuggestionEmail="zzzz", SuggestionName="TestPlace", SuggestionPostCode="Tester",
                                                    SuggestionTel="028000000"});
            //act
            Assert.NotNull(ls);
            //Assert properties are set
            Assert.Equal(ls.SuggestionType, "Test");
            Assert.Equal(ls.SuggestionAddress1, "xxxx");
            Assert.Equal(ls.SuggestionAddress2, "yyyy");
            Assert.Equal(ls.SuggestionEmail, "zzzz");
            Assert.Equal(ls.SuggestionName, "TestPlace");
            Assert.Equal(ls.SuggestionPostCode, "Tester");
            Assert.Equal(ls.SuggestionTel, "028000000");

        }

        [Fact] 
        public void GetAllSuggestions_WhenNone_ShouldReturn0()
        {
            
            var vehicles = svc.GetLocationSuggestion();
            var count = vehicles.Count;

            Assert.Equal(0, count);
        }

        [Fact]
        public void GetSuggestions_With2Added_ShouldReturn2()
        {
            // arrange
            var ls1 = svc.AddLocationSuggestion(new LocationSuggestion{SuggestionType="Test", SuggestionAddress1="xxxx", SuggestionAddress2="yyyy",
                                                    SuggestionEmail="zzzz", SuggestionName="TestPlace", SuggestionPostCode="Tester",
                                                    SuggestionTel="028000000"});
            var ls2 = svc.AddLocationSuggestion(new LocationSuggestion{SuggestionType="Test", SuggestionAddress1="xxxx", SuggestionAddress2="yyyy",
                                                    SuggestionEmail="zzzz", SuggestionName="TestPlace", SuggestionPostCode="Tester",
                                                    SuggestionTel="028000000"});
            // act
            var suggestions = svc.GetLocationSuggestion();
            var count = suggestions.Count;

            // assert
            Assert.Equal(2, count);
        }

        [Fact] 
        private void Getsuggestion_WhenNone_ShouldReturnNull()
        {
            // act 
            var suggestion = svc.GetLocationSuggestionById(1); // non existent vehicle

            // assert
            Assert.Null(suggestion);
        }

        [Fact] 
        public void GetSuggestion_WhenAdded_ShouldReturnSuggestion()
        {
            //arrange
            var ls1 = svc.AddLocationSuggestion(new LocationSuggestion{SuggestionType="Test", SuggestionAddress1="xxxx", SuggestionAddress2="yyyy",
                                                    SuggestionEmail="zzzz", SuggestionName="TestPlace", SuggestionPostCode="Tester",
                                                    SuggestionTel="028000000"});//act
            var nv = svc.GetLocationSuggestionById(ls1.Id);

            // assert
            Assert.NotNull(nv);
            Assert.Equal(ls1.Id, nv.Id);
        }

        [Fact]
        public void DeleteSuggestion_ThatExists_ShouldReturnTrue()
        {
            // act 
            var ls1 = svc.AddLocationSuggestion(new LocationSuggestion{SuggestionType="Test", SuggestionAddress1="xxxx", SuggestionAddress2="yyyy",
                                                    SuggestionEmail="zzzz", SuggestionName="TestPlace", SuggestionPostCode="Tester",
                                                    SuggestionTel="028000000"});//act
            var deleted = svc.DeleteLocationSuggestion(ls1.Id);

            // assert
            Assert.True(deleted);
        }

        [Fact]
        public void DeleteSuggestion_ThatDoesntExist_ShouldReturnFalse()
        {
            // act 	
            var deleted = svc.DeleteLocationSuggestion(8);

            // assert
            Assert.False(deleted);
        }

        // LocationSuggestion Units Tests ^

        // User Units Tests v
        
        // User Units Tests ^

    }
}
