using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PetBuddy.Data.Models;
using Web.ViewModels;
using PetBuddy.Data.Services;
using PetBuddy.Data.Repository;
using PetBuddy.Data.Models.Places;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace Web.Controllers
{
      [Authorize]   
     public class PlacesController : BaseController
    {
        private readonly PetBuddyService svc; 

        public PlacesController()
        {
            svc = new PetBuddyService();
        }

        public IActionResult PlacesIndex(string filter)
        {
            var locations = svc.GetLocations(filter);
            
            return View(locations);
        }

        public IActionResult PlacesMap(int id)
        {
        var location = svc.GetLocationById(id);

        if(location == null)
            {
            return NotFound();
            }
            ViewBag.LocationName = location.LocationName;
        return View(location);
        }
        [Authorize(Roles = "Admin")]
        public IActionResult CreatePlace ()
        {
            return View();
        }
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult CreatePlace (Location l)
        {
            if(ModelState.IsValid)
            {
                svc.AddLocation(new Location{LocationAddress1 = l.LocationAddress1,
                LocationAddress2 = l.LocationAddress2,
                LocationEmail = l.LocationEmail,
                LocationName = l.LocationName,
                LocationType = l.LocationType,
                LocationEmbedMap = l.LocationEmbedMap,
                LocationPostCode = l.LocationPostCode,
                LocationTel = l.LocationTel});
                Alert("Location successfully added", AlertType.success);
                return RedirectToAction(nameof(PlacesIndex));
            }
            return View(l);
        }
            [Authorize(Roles = "Admin")]
            public IActionResult EditPlace(int id)
            {
              var location = svc.GetLocationById(id);  
                if(location == null)
                {
                    return NotFound();
                }
                return View(location);
            }

            [Authorize(Roles = "Admin")]
            [HttpPost]
            public IActionResult EditPlace(int id, Location l)
            {
                if(ModelState.IsValid)
                {
                    svc.EditLocation(id, l);
                    Alert("Location successfully edited", AlertType.warning);
                    return RedirectToAction(nameof(PlacesIndex));
                }
                return View(l);
            }

            [Authorize(Roles = "Admin")]
            public IActionResult DeletePlace(int id)
            {
                var location = svc.GetLocationById(id);
                if(location ==null){
                    return NotFound();
                }
                return View(location);
            }
            [Authorize(Roles = "Admin")]
            [HttpPost]
            public IActionResult DeletePlaceConfirm(int id)
            {
            
             
                svc.DeleteLocation(id);
             
                Alert("Location successfully deleted", AlertType.danger);
                return RedirectToAction(nameof(PlacesIndex));
            }  
            [Authorize(Roles = "Admin, Member")]
            public IActionResult CreatePlaceSuggestion ()
            {
            return View();
            }
            [Authorize(Roles = "Admin, Member")]
             [HttpPost]
             public IActionResult CreatePlaceSuggestion (LocationSuggestion l)
            {
            if(ModelState.IsValid){
                svc.AddLocationSuggestion(new LocationSuggestion{SuggestionAddress1 = l.SuggestionAddress1,
                SuggestionAddress2 = l.SuggestionAddress2,
                SuggestionEmail = l.SuggestionEmail,
                SuggestionName = l.SuggestionName,
                SuggestionPostCode = l.SuggestionPostCode,
                SuggestionTel = l.SuggestionTel,
                SuggestionType = l.SuggestionType});
                Alert("Suggestion sent", AlertType.success);
                return RedirectToAction(nameof(PlacesIndex));
            }
            return View(l);
            }
            [Authorize(Roles = "Admin")]
            public IActionResult PlacesSuggestions ()
            {
                var suggestions = svc.GetLocationSuggestion();
                return View(suggestions);
            }
            [Authorize(Roles = "Admin")]
            public IActionResult DeletePlaceSuggestion(int id)
            {
                var suggestion = svc.GetLocationSuggestionById(id);
                if(suggestion ==null){
                    return NotFound();
                }
                return View(suggestion);
            
            }

            [Authorize(Roles = "Admin")]
            [HttpPost]
            public IActionResult DeletePlaceSuggestionConfirm(int id)
            {
            
                // delete student via service
                svc.DeleteLocationSuggestion(id);
                // redirect to the index view
                Alert("Suggestion successfully deleted", AlertType.success);
                return RedirectToAction(nameof(PlacesSuggestions));
            } 




    }

}