using Microsoft.AspNetCore.Mvc;
using PetBuddy.Data.Services;
using PetBuddy.Data.Models.Blog;
using System;
using System.Threading.Tasks;
using Web.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using PetBuddy.Data.Models.HealthChecker;



namespace Web.Controllers
{
    [Authorize]
    public class HealthCheckerController : BaseController
    {
    private readonly PetBuddyService svc;

    public HealthCheckerController() 
        {
          svc = new PetBuddyService();
    }

    public IActionResult HealthCheckerIndex()
    {
       
        return View();
    }

    [Authorize(Roles = "Admin, Member")]
    [HttpPost]
        public IActionResult HealthCheckerIndex (Symptoms s)
        {
            if(ModelState.IsValid)
            {
                return RedirectToAction(nameof(HealthCheckerDiagnosis));
            }
            return View(s);
        }

        [Authorize(Roles = "Admin, Member")]
        public IActionResult HealthCheckerDiagnosis (Symptoms s)
        {

            var diagnosis = svc.MatchingIllness(s);
            if(diagnosis == null)
            {
                return RedirectToAction(nameof(HealthCheckerDiagnosisUnknown));
            }
            return View(diagnosis);
        }


        [Authorize(Roles = "Admin, Member")]
        public IActionResult HealthCheckerDiagnosisUnknown (Symptoms s)
        {

            return View();
        }



    }
}