using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PetBuddy.Data.Models;
using PetBuddy.Data.Services;
using Web.ViewModels;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Threading.Tasks;
using PetBuddy.Data.Models.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;


namespace Web.Controllers
{

     public class UserController : BaseController
    {
         private readonly IPetBuddyService _svc;

        public UserController()
        {
            _svc = new PetBuddyService();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost] 
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("EmailAddress,Password")]UserViewModel m)
        {   
            // call service to Autheticate User
            var user = _svc.Authenticate(m.EmailAddress, m.Password);  
            
            // verify if user found and if not then add a model state e
            if (user == null)
            {
                ModelState.AddModelError("EmailAddress", "Invalid Login Credentials");
                ModelState.AddModelError("Password", "Invalid Login Credentials");
                return View(m);
            }  
               
            // sign user in using cookie authentication to store principal
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                BuildClaimsPrincipal(user)
            );
            return RedirectToAction("Index","Home");
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register([Bind("Name,EmailAddress,Password,PasswordConfirm, Role")]UserViewModel m)
        {
            if (!ModelState.IsValid)
            {
                return View(m);
            }
            var user = _svc.RegisterUser(m.Name, m.EmailAddress, m.Password, m.Role);               

            // check if emailaddress is unique
            if (user == null )
            {
                ModelState.AddModelError("EmailAddress", "EmailAddress has already been used. " +
                                        " Choose another");
                return View(m);
            }
            // registration successful now redirect to login page
            Alert("Registration Successful - Now Login", AlertType.info);          
            return RedirectToAction(nameof(Login));
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction(nameof(Login));
        }

        public IActionResult ErrorNotAuthorised()
        {   
            Alert("Not Authorized - Technical issues should be emailed to PetBuddy@mail.com", AlertType.warning);
            return RedirectToAction("Index", "Home");
        }

        public IActionResult ErrorNotAuthenticated()
        {
            Alert("Not Authenticated", AlertType.warning);
            return RedirectToAction("Login", "User"); 
        }

        private  ClaimsPrincipal BuildClaimsPrincipal(User user)
        { 
            // define user claims
            var claims = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Email, user.EmailAddress),
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Role, user.Role.ToString())                              
            }, CookieAuthenticationDefaults.AuthenticationScheme);

            // build principal using claims
            return  new ClaimsPrincipal(claims);
        }

        [AcceptVerbs("GET", "POST")]
        public IActionResult VerifyEmailAddress(string email)
        {
            if (_svc.GetUserByEmailAddress(email) != null)
            {
                return Json($"Email Address {email} is already in use. Please choose another");
            }
            return Json(true);
        }


        [Authorize(Roles = "Admin")]
        public IActionResult UserIndex(string filter)
        {
            var users = _svc.GetAllUsers();
        
            return View(users);
        }


        [Authorize(Roles = "Admin")]
        public IActionResult EditUser(int id)
        {
            var user = _svc.GetUserById(id);
            if(user == null)
                {
                return NotFound();
                }
                return View(user);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult EditUser(int id, User u)
            {
                if(ModelState.IsValid)
                {
                    _svc.EditUser(id, u);
                    Alert("User details successfully edited", AlertType.warning);
                    return RedirectToAction(nameof(UserIndex));
                }
                return View(u);
        }


        [Authorize(Roles = "Admin")]
        public IActionResult DeleteUser(int id)
        {
            var user = _svc.GetUserById(id);
            if(user ==null){
                return NotFound();
            }
            return View(user);
        }


        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeleteUserConfirm(int id)
        {
        _svc.DeleteUser(id);
            
        Alert("User successfully deleted", AlertType.danger);
        return RedirectToAction(nameof(UserIndex));
        } 

        public IActionResult EditUserByMember(int id)
        {
            var user = _svc.GetUserById(id);
            if(user == null)
                {
                return NotFound();
                }
                return View(user);
        }


        [HttpPost]
        public IActionResult EditUserByMember(int id, User u)
            {
                if(ModelState.IsValid)
                {
                    _svc.EditDetailsByUser(id, u);
                    Alert("Details successfully edited", AlertType.warning);
                    return RedirectToAction(nameof(EditUserByMember));
                }
                return View(u); 
        }





    }

}