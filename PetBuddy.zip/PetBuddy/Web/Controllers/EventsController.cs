using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PetBuddy.Data.Models;
using Web.ViewModels;
using PetBuddy.Data.Services;
using PetBuddy.Data.Repository;
using PetBuddy.Data.Models.Events;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;


namespace Web.Controllers
{
    [Authorize]
     public class EventsController : BaseController
    {
        private readonly PetBuddyService svc; 

        public EventsController()
        {
            svc = new PetBuddyService();
        }

        public IActionResult EventsIndex(string filter)
        {
            var events = svc.GetAllEvents();
            
            return View(events);
        }
        [Authorize(Roles = "Admin, Member")]
        public IActionResult CreateEvent()
        {
        //render blank form
        return View();
        }
        [Authorize(Roles = "Admin, Member")]
        [HttpPost]
        public IActionResult CreateEvent (Event e)
        {
        if(ModelState.IsValid)
        {
            svc.AddEvent(new Event{
                                    EventUrl = e.EventUrl,
                                    EventDescription = e.EventDescription,
                                    EventImage = e.EventImage,
                                    EventLocation = e.EventLocation,
                                    EventStart = e.EventStart,
                                    EventEnd =e.EventEnd,
                                    EventSubject = e.EventSubject});
            Alert("Event successfully added", AlertType.success);
            return RedirectToAction(nameof(EventsIndex));
        }
        return View(e);
        }
        [Authorize(Roles = "Admin")]
        public IActionResult EditEvent (int id)
        {
        var ev = svc.GetEventById(id);
        if(ev == null)
        {
            return NotFound();
        }
        return View(ev);
        }
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult EditEvent (int id, Event e)
        {
            if(ModelState.IsValid)
            {
                svc.EditEvent(id, e);
                Alert("Event details succesfully editted", AlertType.success);
                return RedirectToAction(nameof(EventsIndex));
            }
            return View(e);
        }
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteEvent(int id)
        {
           
            var ev = svc.GetEventById(id);
            if (ev == null)
            {
                return NotFound();
            }
            return View(ev);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeleteEventConfirm(int id)
        {
         
            svc.DeleteEvent(id);
            Alert("Event successfully deleted", AlertType.danger);
            return RedirectToAction(nameof(EventsIndex));
        } 


    }
}

