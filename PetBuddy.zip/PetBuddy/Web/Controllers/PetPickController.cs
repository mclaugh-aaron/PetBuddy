using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PetBuddy.Data.Models;
using Web.ViewModels;
using PetBuddy.Data.Services;
using PetBuddy.Data.Repository;
using PetBuddy.Data.Models.Dogs;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using PetBuddy.Data.Models.Pet;

namespace Web.Controllers
{
    [Authorize]
        
     public class PetPickController : BaseController
    {
        private readonly PetBuddyService svc; 

        public PetPickController()
        {
            svc = new PetBuddyService();
        }

        public IActionResult CreatePick ()
        {

            return View();

        }
        [Authorize(Roles = "Admin, Member")]
        [HttpPost]
        public IActionResult CreatePick (QuizAnswers v)
        {
            if(ModelState.IsValid)
            {
                return RedirectToAction(nameof(PetPicksList));
            }
            return View(v);
        }
        
        [Authorize(Roles = "Admin, Member")]
        public IActionResult PetPicksList (QuizAnswers b)
        {

            var chosenPet = svc.MatchingBreed(b);
            if(chosenPet == null)
            {
                return RedirectToAction(nameof(PetPickUnknown));
            }
            return View(chosenPet);
        }
        [Authorize(Roles = "Admin, Member")]
        public IActionResult PetsByBreed (string filter)
        {
            
            var pets = svc.GetPetsThatMatchBreed(filter);

            return View(pets);
        }


        [Authorize(Roles = "Admin, Member")]
        public IActionResult PetPickUnknown (string filter)
        {

            return View();
        }


    }

}