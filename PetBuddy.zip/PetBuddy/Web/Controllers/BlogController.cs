using Microsoft.AspNetCore.Mvc;
using PetBuddy.Data.Services;
using PetBuddy.Data.Models.Blog;
using System;
using System.Threading.Tasks;
using Web.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;



namespace Web.Controllers
{
    [Authorize]
    public class BlogController : BaseController
    {
    private readonly PetBuddyService svc;

    public BlogController() 
        {
          svc = new PetBuddyService();
    }

    public IActionResult BlogIndex(string filter)
    {
        var posts = svc.GetAllPosts(filter);
        return View(posts);
    }

    public IActionResult BlogPost(int id)
    {
        var post = svc.GetPostById(id);
        if(post == null){
            return NotFound();
        }
        return View(post);
    }

    [Authorize(Roles = "Admin, Member")]
    public IActionResult CreatePost ()
    {
        return View();
    }

    [Authorize(Roles = "Admin, Member")]
    [HttpPost]
     public IActionResult CreatePost (Post p)
    {
        if(ModelState.IsValid){
            svc.AddPost(new Post{Author = p.Author,
            Title = p.Title,
            Snippet = p.Snippet,
            Content = p.Content,
            Category = p.Category});
            Alert("Post added", AlertType.success);
            return RedirectToAction(nameof(BlogIndex));
        }
        return View(p);
    }
        [Authorize(Roles = "Admin")]
        public IActionResult EditPost(int id)
    {
        var post = svc.GetPostById(id);
        if(post == null)
        {
            return NotFound();
        }
        return View(post);
    }

    [Authorize(Roles = "Admin")]
    [HttpPost]
    public IActionResult EditPost(int id, Post p)
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        if(ModelState.IsValid)
        {
            svc.EditPost(id, p);
             Alert("Post succesfully editted", AlertType.warning);
            return RedirectToAction(nameof(BlogIndex));
        }
        return View(p);
    }
        [Authorize(Roles = "Admin")]
        public IActionResult DeletePost(int id)
        {
            
            var post = svc.GetPostById(id);
            if (post == null)
            {
                return NotFound();
            }
    
            return View(post);
        }
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeletePostConfirm(int id)
        {
          
            svc.DeletePost(id);
             Alert("Post successfully deleted", AlertType.danger);
            return RedirectToAction(nameof(BlogIndex));
        }  
        [Authorize(Roles = "Admin, Member")]
        public IActionResult AddNewPostComment(int id)
        {
          
            var s = svc.GetPostById(id);
            if(s == null)
            {
                return NotFound();
            }
            ViewBag.postTitle = s.Title;
            ViewBag.postContent = s.Content;
            ViewBag.postAuthor = s.Author;
            ViewBag.DateAndTime = s.PostedOnDate;
         
            var svm = new CommentViewModel{PostId = id};
                
        
            return View(svm);
        }  
        [Authorize(Roles = "Admin, Member")]
        [HttpPost]
        public  IActionResult AddNewPostComment(CommentViewModel s)
        {
        
            if(ModelState.IsValid)
            {
                svc.AddNewComment(s.PostId, s.Author, s.CommentBody);
                 Alert("Comment added", AlertType.success);
                return RedirectToAction("BlogPost", new {Id = s.PostId});
            }
            return View(s);
        }
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteComment(int id)
        {
            
            var comment = svc.GetCommentById(id);
            if (comment == null)
            {
                return NotFound();
            }
  
            return View(comment);
        }
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeleteCommentConfirm(int id)
        {
            var comment = svc.GetCommentById(id);
        
            svc.DeleteComment(id);
            Alert("Comment successfully deleted", AlertType.danger);
            return RedirectToAction("BlogPost", new{Id = comment.PostId});
        }  

    }
}
