using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PetBuddy.Data.Models;
using Web.ViewModels;
using PetBuddy.Data.Services;
using PetBuddy.Data.Repository;
using PetBuddy.Data.Models.Events;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using PetBuddy.Data.Models.Pet;


namespace Web.Controllers
{
    [Authorize]
     public class PetsController : BaseController
    {
        private readonly PetBuddyService svc; 

        public PetsController()
        {
            svc = new PetBuddyService();
        }
        [Authorize(Roles = "Admin, Member")]
        public IActionResult PetsIndex(string filter)
        {
            var pets = svc.GetAllPets();
            
            return View(pets);
        }
        [Authorize(Roles = "Admin, Member")]
        public IActionResult PetProfile (int id)
        {
            var pet = svc.GetPetById(id);
            if(pet == null)
            {
                return NotFound();
            }
            return View(pet);
        }
        [Authorize(Roles = "Admin, Member")]
        public IActionResult CreatePet()
        {
        //render blank form
        return View();
        }

        [Authorize(Roles = "Admin, Member")]
        [HttpPost]
        public IActionResult CreatePet (PetViewModel p)
        {
            if(ModelState.IsValid)
            {
                svc.AddPet(new Pet{PetName = p.PetName,
                                    BreedName = p.BreedName,
                                    PetAge = p.PetAge,
                                    PetBio = p.PetBio,
                                    PetOwnerName = p.PetOwnerName,
                                    PetPicUrl = p.PetPicUrl});
                Alert("Pet successfully added", AlertType.success);
                return RedirectToAction(nameof(PetsIndex));
               
            }
            return View(p);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult EditPet(int id)
        {
        var pet = svc.GetPetById(id);
        if(pet == null)
        {
            return NotFound();
        }
        return View(pet);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult EditPet(int id, Pet p)
        {
            if(ModelState.IsValid)
            {
                svc.EditPet(id, p);
                Alert("Pet details succesfully editted", AlertType.success);
                return RedirectToAction(nameof(PetsIndex));
            }
            return View(p);
        }   

        [Authorize(Roles = "Admin")]
        public IActionResult DeletePet(int id)
        {
            // load student via service         
            var pet = svc.GetPetById(id);
            if (pet == null)
            {
                return NotFound();
            }
            // pass student to view for deletion confirmation
            return View(pet);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeletePetConfirm(int id)
        {
            // delete student via service
            svc.DeletePet(id);
            Alert("Pet successfully deleted", AlertType.danger);
            // redirect to the index view
            return RedirectToAction(nameof(PetsIndex));
        }   

        [Authorize(Roles = "Admin, Member")]
        public IActionResult AddNewPetComment (int id)
        {
            var s = svc.GetPetById(id);
            if(s == null)
            {
                return NotFound();
            }
            //create a ticket view model
            var petcomment = new PetComments{PetId = id};
            
                
            //render form
            return View(petcomment);
        } 

        [Authorize(Roles = "Admin, Member")]
        [HttpPost]
        public  IActionResult AddNewPetComment (PetComments p)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            if(ModelState.IsValid)
            {
                svc.AddNewPetComment(p.PetId, p.Author, p.CommentBody);
                Alert("Comment successfully added", AlertType.success);
                return RedirectToAction("PetProfile", new {Id = p.PetId});
            }
            return View(p);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult DeletePetComment(int id)
        {
            // load student via service         
            var comment = svc.GetPetCommentById(id);
            if (comment == null)
            {
                return NotFound();
            }
            // pass student to view for deletion confirmation
            return View(comment);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeletePetCommentConfirm(int id)
        {
            var comment = svc.GetPetCommentById(id);
            // delete service via service
            svc.DeletePetComment(id);
            Alert("Comment successfully deleted", AlertType.danger);
            // redirect to the vehicle details view
            return RedirectToAction("PetProfile", new{Id = comment.PetId});
        }  

         [Authorize(Roles = "Admin, Member  ")]
        public IActionResult AddNewPetPhoto (int id)
        {
            var s = svc.GetPetById(id);
            if(s == null)
            {
                return NotFound();
            }
        
            var petphoto = new PetPhoto{PetId = id};
       
            return View(petphoto);
        } 

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public  IActionResult AddNewPetPhoto(PetPhoto p)
        {
            if(ModelState.IsValid)
            {
                svc.AddNewPetPhoto(p.PetId, p.PetPhotoUrl);
                Alert("Photo successfully added", AlertType.success);
                return RedirectToAction("PetProfile", new {Id = p.PetId});
            }
            return View(p);
        }


        [Authorize(Roles = "Admin")]
        public IActionResult DeletePetPhoto(int id)
        {
            // load student via service         
            var photo = svc.GetPetById(id);
            if (photo == null)
            {
                return NotFound();
            }
            // pass student to view for deletion confirmation
            return View(photo);
        }

           [Authorize(Roles = "Admin")]
            public IActionResult DeleteImage(int id)
            {
                var image = svc.GetPetPhotoById(id);
                if(image ==null){
                    return NotFound();
                }
                return View(image);
            }
            [Authorize(Roles = "Admin")]
            [HttpPost]
            public IActionResult DeleteImageConfirm(int id)
            {
            
            var image = svc.GetPetPhotoById(id);
            // delete service via service
            svc.DeletePetPhoto(id);
            Alert("Photo successfully deleted", AlertType.danger);
            // redirect to the vehicle details view
            return RedirectToAction("PetProfile", new{Id = image.PetId});
            }  


    }
}