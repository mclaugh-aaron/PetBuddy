using System.ComponentModel.DataAnnotations;
using System;


namespace Web.ViewModels
{
    public class CommentViewModel
    {
        public int PostId { get; set; }
        [Required]
        public string Author { get; set; }
        [Required]
        public string CommentBody { get; set; }

        public DateTime CommentDATE => (DateTime.Now);



    }
        
}