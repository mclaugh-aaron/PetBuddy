using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using PetBuddy.Data.Models.Pet;

namespace Web.ViewModels
{
    public class PetViewModel
    {
        public int Id { get; set; }
        [Required]  
        public BreedName BreedName { get; set; }
        [Required]  
        public string PetName { get; set; }
        [Required]  
        public string PetOwnerName { get; set; } 
        public string PetBio { get; set; }
        [Required]  
        public int PetAge { get; set; }
        [Required]  
        [Url]  
        public string PetPicUrl { get; set; }
        [Required]  
        public string FacebookAccount { get; set; }
        [Required]  
        public string InstagramAccount { get; set; }

    }
}