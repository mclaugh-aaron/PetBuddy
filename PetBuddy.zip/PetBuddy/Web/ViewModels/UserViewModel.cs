using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using PetBuddy.Data.Models.User;


namespace Web.ViewModels
{
    public class UserViewModel
    {  
        [Required]
        [EmailAddress]
        [Remote(action: "VerifyEmailAddress", controller: "User")]
        public string EmailAddress { get; set; }
 
        [Required]
        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Confirm password doesn't match, Type again !")]
        public string PasswordConfirm  { get; set; }

        
        public Role Role => (Role.Member);

        [Required]
        public string Name { get; set; }


    }
}